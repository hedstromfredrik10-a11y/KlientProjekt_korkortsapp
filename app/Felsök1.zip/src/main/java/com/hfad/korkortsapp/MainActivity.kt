package com.hfad.korkortsapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.hfad.korkortsapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var quizModellist: MutableList<QuizModel>
    lateinit var adapter: QuizListAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)

        quizModellist = mutableListOf()
        getDataFromFirebase()


    }



    private fun getDataFromFirebase() {
        quizModellist.add(QuizModel("1", "Skyltar", "Allt om skyltar", "15"))
        quizModellist.add(QuizModel("2", "Miljö", "Allt om miljö", "15"))
        quizModellist.add(QuizModel("3", "Bilen", "Allt om bilen", "15"))
        setUpRecyclerView()

    }

    private fun setUpRecyclerView() {
        adapter = QuizListAdapter(quizModellist)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

    }


}